struct mi
{	 
   char cname[40],mobnm[40],pro[40],os[40],sensors[40];
	int year,battery,price[5],dim[3],weight,cam[2],mem[2],net;
	float osver;
};
struct mi2
{	 
   char cname[40],mobnm[40],pro[40],os[40],sensors[40];
unsigned long	int price[5]; 
int year,battery,dim[3],weight,cam[2],mem[2],net,osver;
};
void main()
{  clrscr();
   int i=11;
   while(i)
   { 
   	i--;
   }

   getch();
	
}