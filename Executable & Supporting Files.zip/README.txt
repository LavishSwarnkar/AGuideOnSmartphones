        Welcome to THE GUIDE ON SMART PHONES Version 1.0
        ------------------------------------------------

This README file contains important information about the program 
GUIDE ON SMART PHONES MADE BY LAVISH SWARNKAR. For the latest inf
ormation about it and its accompanying features and manuals, read 
this file in its entirety.

TABLE OF CONTENTS
-----------------
1.  Help
2.  Installation
3.  Features
4.  Important Information
5.  Contact


 1. HELP
-------------------
If you have any problems, please read this file. The moment you op
en the .exe file provided in the preceeding folder , you will come 
across a presentation stating about the developer and the program. 
After that you will be redirected you login screen. Here you see 4 
options:

  1.  NEW USER? CREATE A NEW ACCOUNT!
  2.  EXISTING USER? LOGIN!
  3.  CHANGE PASSWORD.
  4.  FORGOT PASSWORD? RENEW IT!

If its your first time to this program, create a new acount by pre
ssing 'C' key after navigating to the option by arrow keys. Simila
rly, you can use othe options too. When you login, you are further 
redirectedto the main menu after a small  presentation.. Again you 
see a menu whose features are described below in features section.

 2. INSTALLATION
----------------
No need to go through any wizards. Just start using the program by 
opening the .exe file.
 

 3. FEATURES
------------

Guide on Smart Phones 1.0 includes a beginners guide for the same.  
Here are some important features found in this version:

  - Brief history of smart phones.

  - Brief description on some important features of smart phones , 
    viz., os.

  - Some popular smart phones decription.

  - Filter Smart phones as required.

  - See number of entries done till that moment.

  - Add more smart phones description.
    
  - Interesting facts on smart phones.

 4. IMPORTANT INFORMATION
-------------------------

This program's perfect working is solely depended on the availibity 
of the files present in the preceeding folder. Please do not try to 
alter or delete them else you might not be able to take complete ad
vantage of this program.

 5. CONTACT
-----------

Not yet satisfied! Don't worry, you can contact me at my  website , 
lavishswarnkar.tk or my blog lavishswarnkar.blogspot.com  or e-mail 
me at lavishswarnkar@gmail.com .